public class RelationalOperator{
	public static void main(String[] args){
		int x = 10;
		int y = 25;
		boolean isGreater = x>y;
		System.out.println(isGreater);
		
		boolean isLesser = x<y;
		System.out.println(isLesser);
		
		boolean isGreaterOrEqualTo = x>=y;
		System.out.println(isGreaterOrEqualTo);
		
		boolean isLesserOrEqualTo = x<=y;
		System.out.println(isLesserOrEqualTo);
		
		boolean isNotEqualTo = x!=y;
		System.out.println(isNotEqualTo);
		
		boolean isEqualTo = x==y;
		System.out.println(isEqualTo);
	}
}